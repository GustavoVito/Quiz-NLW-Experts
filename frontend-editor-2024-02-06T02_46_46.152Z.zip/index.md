#HTML

HyperText Markup Language

Tag
Atributos

Div e Span -> container
a div quebra a linha, já o span não

'''Js
const mensagem = "Bom te ver aqui! "
alert(mensagem + (10 * 100) + "abraços")

'''Js

## Array ou Vetores
[]

## Objetos
{}
const celular ={
  cor: 'preto',
  modelo: 'samsung',
  peso: 200
}

alert(celular.peso)